# Bienvenidos a nuestro conversor Markdown-HTML!


 ¡El mejor conversor que te puedas imaginar!
 
 Tiene de todo:
 
 1. Puedes hacer listas ordenadas
 2. Y otro ítem
 3. Y otro

 `Esto es código`
 
 ``Más código, distinta declaración``
 
 + Puedes hacer listas desordenadas
 - Con distintos símbolos
 - Por ejemplo un más, un menos... 

## Permite definir imágenes, links, distintos títulos...

 ![Esto es una imagen](imagen.png)
 
 [Esto es un link](google.com)
 
 [Duck Duck Go](https://duckduckgo.com)
 
 Este texto lleva una acalaración (esta es la aclaración) 
   
 *Cursiva número 1*
 
 _Cursiva número 2_
 
 **Énfasis número 1**
 
 __Énfasis número 2__
 
 ~~Palabra tachada~~
 
 **_Combinación cursiva y énfasis 1 _**
 
 __*Combinación cursiva y énfasis 2*__
 
 ~~_Combinación cursiva y tachado_~~
 
 Hola [corchetes]
 
 Hola *cursiva*  __hola__
 
 
 
 
